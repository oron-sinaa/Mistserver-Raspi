namespace Controller{
  void uplinkConnection(void *np);
}
